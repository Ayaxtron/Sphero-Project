/*
 * sphero.java
 *
 * Created on 19 Nov 2017
 */
/**
 *
 *@author Kai Kawasaki Ueda A01336424
 *@author Jorge Constanzo De la Vega Carrasco A01650285
 *@author Ayax Alexis Casarrubias Rodriguez A01337426
 *@author Alejandro Olivares Arteaga A01337525
 *
 */

public abstract class Instrucciones {
	private int befxcor;
	private int befycor;
	private int nextxcor;
	private int nextycor;

	public Instrucciones() {
		
	}

	public int getBefxcor() {
		return befxcor;
	}

	public void setBefxcor(int befxcor) {
		this.befxcor = befxcor; 
	}

	public int getBefycor() {
		return befycor;
	}

	public void setBefycor(int befycor) {
		this.befycor = befycor;
	}

	public int getNextxcor() {
		return nextxcor;
	}

	public void setNextxcor(int nextxcore) {
		this.nextxcor = nextxcor;
	}

	public int getnextycor() {
		return nextycor;
	}

	public void setNextycor(int nextycor) {
		this.nextycor = nextycor; 
	}
}
