import java.util.Stack;
import java.util.Queue;
import java.util.List;
import java.io.Serializable;

/*
 * sphero.java
 *
 * Created on 19 Nov 2017
 */

/**
 *
 *@author Kai Kawasaki Ueda A01336424
 *@author Jorge Constanzo De la Vega Carrasco A01650285
 *@author Ayax Alexis Casarrubias Rodriguez A01337426
 *@author Alejandro Olivares Arteaga A01337525
 *
 */

public class Sphero implements Serializable{
	private int xcord;
	private int ycord;
	private Queue<Instrucciones> qInst;

	public Sphero(){
		//0,0 change to center of window later.
		this(0,0,null);
	}

	public Sphero(int xcord, int ycord,Queue<Instrucciones> qInst){
		this.xcord = xcord;
		this.ycord = ycord;
		this.qInst = qInst;
	}

	public int getXcord() {
		return xcord; 
	} 

	public void setXcord(int xcord) {
		this.xcord = xcord; 
	}

	public int getYcord() {
		return ycord; 
	}

	public void setYcord(int ycord) {
		this.ycord = ycord; 
	}
	
	public Queue<Instrucciones>getQinst() {
		return qInst; 
	}
	
	public void setQinst(Queue<Instrucciones> qInst) {
		this.qInst = qInst; 
	}
}