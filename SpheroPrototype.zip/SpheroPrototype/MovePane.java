import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ButtonModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.io.*;
import javax.swing.JFileChooser;
import javax.swing.JTextArea;
import javax.swing.ImageIcon;

public class MovePane {

    public static void main(String[] args) {
        new MovePane();
    }

    public MovePane() {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
                }

                JFrame frame = new JFrame("Testing");
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setLayout(new BorderLayout());
                frame.add(new TestPane());
                frame.pack();
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);
                
            }
        });
    }

    public enum Direction {

        None, Up, Down, Left, Right, Reset;
    }

    

    public class TestPane extends JPanel {

        private JPanel mobby;
        private Timer moveTimer;
        private Direction moveDirection = Direction.None;
        private JTextArea ins;
        private Sphero sphero = new Sphero();
        private String[] myArray = new String[100];
        private int cont=0;

        public TestPane() {
            mobby = new JPanel();
            mobby.setBackground(Color.RED);
            mobby.setSize(50, 50);;

            setLayout(new BorderLayout());
            JPanel pool = new JPanel(null);
            pool.add(mobby);
            add(pool);
            JPanel buttons = new JPanel(new GridBagLayout());

            JButton up = new JButton("Upward");
            JButton dwn = new JButton("Downward");
            JButton lft = new JButton("Left");
            JButton rgt = new JButton("Right");
            JButton draw = new JButton("Draw");
             JButton hide = new JButton("Hide");
            JButton reset = new JButton("Reset");
            

            JPanel buttons1 = new JPanel(new GridBagLayout());
            JButton run = new JButton("Run");
            JButton del = new JButton("Delete");
             JButton load = new JButton("Load");
            JButton save = new JButton("Save");



            GridBagConstraints gbc = new GridBagConstraints();
            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.gridx = 0;
            gbc.gridy = 0;

            buttons.add(up, gbc);
            gbc.gridx = 0;
            gbc.gridy = 1;
            buttons.add(dwn, gbc);
            gbc.gridx = 0;
            gbc.gridy = 2;
            buttons.add(lft, gbc);
            gbc.gridx = 0;
            gbc.gridy = 3;
            buttons.add(rgt, gbc);
            gbc.gridx = 0;
            gbc.gridy = 4;
            buttons.add(draw, gbc);
            gbc.gridx = 0;
            gbc.gridy = 5;
            buttons.add(hide, gbc);
            gbc.gridx = 0;
            gbc.gridy = 6;
            buttons.add(reset, gbc);

            add(buttons, BorderLayout.WEST);


            gbc.gridx = 0;
            gbc.gridy = 7;
            buttons1.add(run, gbc);
            gbc.gridx = 1;
            
            buttons1.add(del, gbc);
            gbc.gridx = 0;
            gbc.gridy = 9;
            buttons1.add(load, gbc);
            gbc.gridx = 1;
            gbc.gridwidth = GridBagConstraints.REMAINDER;
            buttons1.add(save, gbc);
            
            add(buttons1, BorderLayout.SOUTH);

            ins = new JTextArea();
            for (int i = 0 ; i < 45 ; i ++ ) {
            ins.append(" ") ;
            }
            ins.append(" \n");
           // ins.setText(sphero.getQinst());
            add(ins,BorderLayout.EAST);


            up.getModel().addChangeListener(new ChangeHandler(Direction.Up));
            dwn.getModel().addChangeListener(new ChangeHandler(Direction.Down));
            lft.getModel().addChangeListener(new ChangeHandler(Direction.Left));
            rgt.getModel().addChangeListener(new ChangeHandler(Direction.Right));
            reset.getModel().addChangeListener(new ChangeHandler(Direction.Reset));
          
            
            moveTimer = new Timer(40, new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    Container parent = mobby.getParent();
                    Rectangle bounds = mobby.getBounds();
                    switch (moveDirection) {
                        case Up:
                            bounds.y--;
                            myArray[cont]="Hacia Arriba \n";
                            ins.append(myArray[cont]);
                           
                            cont=cont+1;
                             //ins.setText(myArray[cont]);
                            /*for(int x=0;x<myArray.length;x++){

                                if(myArray[x]!=null){
                                    ins.append(myArray[x]);

                                }
                            }*/
                            break;
                        case Down:
                            bounds.y++;
                            myArray[cont]="Hacia Abajo \n";
                            ins.append(myArray[cont]);
                           
                            cont=cont+1;
                            break;
                        case Left:
                            bounds.x--;
                            myArray[cont]="Hacia Iquierda \n";
                            ins.append(myArray[cont]);
                           
                            cont=cont+1;
                            break;
                        case Right:
                            bounds.x++;
                            myArray[cont]="Hacia Derecha \n";
                            ins.append(myArray[cont]);
                           
                            cont=cont+1;
                            break; 
                        case Reset: 
                            bounds.y = 0; 
                            bounds.x = 0;
                            System.out.println("Reset being clicked");
                            break;
                    }

                    if (bounds.x < 0) {
                        bounds.x = 0;
                    } else if (bounds.x + bounds.width > parent.getWidth()) {
                        bounds.x = parent.getWidth() - bounds.width;
                    }
                    if (bounds.y < 0) {
                        bounds.y = 0;
                    } else if (bounds.y + bounds.height > parent.getHeight()) {
                        bounds.y = parent.getHeight() - bounds.height;
                    }

                    mobby.setBounds(bounds);

                }
            });
            moveTimer.setInitialDelay(0);
            
        }
       
        @Override
        public Dimension getPreferredSize() {
            return new Dimension(800, 400);
        }

        public class ChangeHandler implements ChangeListener {
            
            private Direction direction;

            public ChangeHandler(Direction direction) {
                this.direction = direction;
            }

            @Override
            public void stateChanged(ChangeEvent e) {
                ButtonModel b = (ButtonModel) e.getSource();
                if (b.isPressed()) {
                    moveDirection = direction;
                    moveTimer.start();
                } else {
                    moveTimer.stop();
                }
            }

        }
    }

}
